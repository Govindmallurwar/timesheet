#!/bin/bash

DOCKER_ARGS=""
if docker ps | grep -Eq -e "postgres"; then
  DOCKER_ARGS="--no-deps"
fi

echo DOCKER_ARGS=$DOCKER_ARGS

if [ $# -eq 0 ]; then
  echo "Running (full system mode)"
  echo "Containers: Environment: postgres, Service: api"
  ./gradlew clean build -Xtests
  docker-compose up --build api $DOCKER_ARGS
else
  echo "Running (API only)"
  echo "Containers: Service: api"
#  ./gradlew clean build -Xtests
#  docker-compose up --build api $DOCKER_ARGS
fi