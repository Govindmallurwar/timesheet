package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

@Data
public class AuthenticationRequestDto {
    private String email;
    private String password;
}
