package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.EmployeeDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeDetailRepository extends JpaRepository<EmployeeDetail, String> {
    List<EmployeeDetail> findByEmployeeId(String employeeId);
}
