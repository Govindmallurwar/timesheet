package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.ProjectEmployeeDto;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Data
@Entity
public class ProjectEmployee {
    @Id
    private String id;
    private String projectId;
    private String employeeId;
    private String employeeProjectRoleId;
    private LocalDate startDate;
    private LocalDate endDate;

    public ProjectEmployeeDto toDto() {
        ProjectEmployeeDto dto = new ProjectEmployeeDto();

        dto.setId(this.getId());
        dto.setProjectId(this.getProjectId());
        dto.setEmployeeId(this.getEmployeeId());
        dto.setEmployeeProjectRoleId(this.getEmployeeProjectRoleId());
        dto.setStartDate(this.getStartDate());
        dto.setEndDate(this.getEndDate());

        return dto;
    }
}
