package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.TimesheetDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "daily_timesheet")
public class Timesheet {
    @Id
    private String id;

    String companyId;
    String companyName;
    String clientId;
    String clientName;
    String projectId;
    String projectName;
    String employeeId;
    String firstName;
    String lastName;
    String projectEmployeeTimeBookedId;
    LocalDateTime effectiveDate;
    Integer bookedUnits;
    String projectEmployeeId;
    String projectTimeUnitId;
    String unit;
    Integer baseUnit;
    Integer effectiveDateYear;
    Integer effectiveDateMonth;
    Integer effectiveDateDay;
    String effectiveDateDayName;
    String effectiveDateYearWeek;
    LocalDate effectiveDateFirstDayOfWeekSunday;
    LocalDate effectiveDateFirstDayOfWeekMonday;


    public TimesheetDto toDto() {
        TimesheetDto dto = new TimesheetDto();

        dto.setCompanyId(this.getCompanyId());
        dto.setCompanyName(this.getCompanyName());
        dto.setClientId(this.getClientId());
        dto.setClientName(this.getClientName());
        dto.setProjectId(this.getProjectId());
        dto.setProjectName(this.getProjectName());
        dto.setEmployeeId(this.getEmployeeId());
        dto.setFirstName(this.getFirstName());
        dto.setLastName(this.getLastName());
        dto.setProjectEmployeeTimeBookedId(this.getProjectEmployeeTimeBookedId());
        dto.setEffectiveDate(this.getEffectiveDate());
        dto.setBookedUnits(this.getBookedUnits());
        dto.setProjectEmployeeId(this.getProjectEmployeeId());
        dto.setProjectTimeUnitId(this.getProjectTimeUnitId());
        dto.setUnit(this.getUnit());
        dto.setBaseUnit(this.getBaseUnit());
        dto.setEffectiveDateYear(this.getEffectiveDateYear());
        dto.setEffectiveDateMonth(this.getEffectiveDateMonth());
        dto.setEffectiveDateDay(this.getEffectiveDateDay());
        dto.setEffectiveDateDayName(this.getEffectiveDateDayName());
        dto.setEffectiveDateYearWeek(this.getEffectiveDateYearWeek());
        dto.setEffectiveDateFirstDayOfWeekSunday(this.getEffectiveDateFirstDayOfWeekSunday());
        dto.setEffectiveDateFirstDayOfWeekMonday(this.getEffectiveDateFirstDayOfWeekMonday());

        return dto;
    }
}
