package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

@Data
public class EmployeeDetailsKeyDto {
    private String id;
    private String companyId;
    private String detailKey;
    private String detailType;
    private Integer displayOrder;

}
