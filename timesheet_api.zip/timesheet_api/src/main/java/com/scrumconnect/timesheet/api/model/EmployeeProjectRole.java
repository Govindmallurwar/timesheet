package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.EmployeeProjectRoleDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class EmployeeProjectRole {
    @Id
    private String id;
    private String projectId;
    private String title;
    private String shortCode;
    private Integer displayOrder;

    public EmployeeProjectRoleDto toDto() {
        EmployeeProjectRoleDto dto = new EmployeeProjectRoleDto();

        dto.setId(this.getId());
        dto.setProjectId(this.getProjectId());
        dto.setTitle(this.getTitle());
        dto.setShortCode(this.getShortCode());
        dto.setDisplayOrder(this.getDisplayOrder());

        return dto;
    }
}
