package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class ProjectEmployeeTimeBookedDto {
    private String id;
    private String projectEmployeeId;
    private String projectTimeUnitId;
    private LocalDateTime effectiveDate;
    private Integer units;
    private List<ProjectEmployeeTimeStatusDto> statuses;
}
