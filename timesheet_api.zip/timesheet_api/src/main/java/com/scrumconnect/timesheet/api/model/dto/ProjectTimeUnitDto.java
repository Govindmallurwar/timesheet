package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ProjectTimeUnitDto {
    private String id;
    private String projectId;
    private LocalDate effectiveDate;
    private String unit;
    private Integer baseUnit;
}
