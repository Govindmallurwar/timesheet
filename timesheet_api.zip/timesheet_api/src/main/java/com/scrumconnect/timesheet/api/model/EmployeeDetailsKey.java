package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.EmployeeDetailsKeyDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class EmployeeDetailsKey {
    @Id
    private String id;
    private String companyId;
    private String detailKey;
    private String detailType;
    private Integer displayOrder;


    public EmployeeDetailsKeyDto toDto() {
        EmployeeDetailsKeyDto dto = new EmployeeDetailsKeyDto();

        dto.setId(this.getId());
        dto.setCompanyId(this.getCompanyId());
        dto.setDetailKey(this.getDetailKey());
        dto.setDetailType(this.getDetailType());
        dto.setDisplayOrder(this.getDisplayOrder());

        return dto;
    }
}
