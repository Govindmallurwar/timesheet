package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.Company;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.CompanyDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewCompanyDto;
import com.scrumconnect.timesheet.api.service.CompanyService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@CrossOrigin
@RequestMapping(path = "/company")
public class CompanyController {
    @Autowired
    private CompanyService companyService;


    @GetMapping(
            produces = "application/json"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<CompanyDto> findCompanyForLoggedInUser() {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(employee -> {
                    Optional<Company> companyOptional = companyService.findById(employee.getEmployee().getCompanyId());

                    return companyOptional
                            .map(company ->
                                    {
                                        CompanyDto dto = company.toDto();
                                        return ResponseEntity.ok(dto);
                                    }
                            )
                            .orElseGet(() ->
                                    ResponseEntity.notFound().build()
                            );
                })
                .orElseGet(() -> ResponseEntity.status(401).build());
    }

    @GetMapping(value = "/all")
    public ResponseEntity<List<CompanyDto>> findAll() {
        List<CompanyDto> dtos = companyService.findAll().stream().map(Company::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<CompanyDto> findOne(@PathVariable("id") String id) {
        return companyService.findOne(id)
            .map(company -> ResponseEntity.ok(company.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<CompanyDto> add(@RequestBody NewCompanyDto newCompanyDto) {
        return ResponseEntity.ok(companyService.save(newCompanyDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (companyService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
