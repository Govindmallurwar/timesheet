package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.ProjectEmployee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProjectEmployeeRepository extends JpaRepository<ProjectEmployee, String> {
    List<ProjectEmployee> findByProjectId(String projectId);
    List<ProjectEmployee> findByEmployeeProjectRoleId(String employeeProjectRoleId);
    List<ProjectEmployee> findByEmployeeId(String employeeId);
}
