package com.scrumconnect.timesheet.api.util;

import com.scrumconnect.timesheet.api.model.User;
import lombok.NoArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

@NoArgsConstructor
public class EmployeeUtil {
    public static boolean employeeIsPrincipalUser(String employeeId, Authentication authentication) {
        return ((User) authentication.getPrincipal()).getEmployee().getId().equals(employeeId);
    }

    public static Optional<User> getLoggedInEmployee() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {
            return Optional.of((User) authentication.getPrincipal());
        } else {
            return Optional.empty();
        }
    }

    public static Optional<User> getLoggedInEmployee(String employeeId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && employeeIsPrincipalUser(employeeId, authentication)) {
            return Optional.of((User) authentication.getPrincipal());
        } else {
            return Optional.empty();
        }
    }
}
