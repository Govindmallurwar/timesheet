package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.DashboardStatsOverview;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.service.DashboardStatsService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@RequestMapping(path = "/dashboard-stats")
public class DashboardStatsOverviewController {
    private final DashboardStatsService dashboardStatsService;

    public DashboardStatsOverviewController(DashboardStatsService dashboardStatsService) {
        this.dashboardStatsService = dashboardStatsService;
    }

    @GetMapping("/overview")
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<DashboardStatsOverview> statsOverview() {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(employee -> ResponseEntity.ok(dashboardStatsService.getOverview(employee)))
                .orElseGet(() -> ResponseEntity.status(401).build());
    }
}
