package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

@Data
public class EmployeeTypeDto {
    private String id;
    private String companyId;
    private String title;
    private Integer displayOrder;

}
