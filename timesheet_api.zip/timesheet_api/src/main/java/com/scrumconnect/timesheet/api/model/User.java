package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.UserDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

@Data
@Entity
@Table(name = "User")
public class User implements UserDetails {
    @Id
    private String id;
    private String email;
    private String avatar;
    private String passwordHash;
    private String role;

    @ManyToOne
    private Employee employee;

    public UserDto toDto() {
        UserDto dto = new UserDto();

        dto.setId(UUID.fromString(this.getId()));
        dto.setEmail(this.getEmail());
        dto.setAvatar(this.getAvatar());
        dto.setRole(this.getRole());
        dto.setEmployee(this.getEmployee().toDto());

        return dto;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of();
    }

    public String getPassword() {
        return passwordHash;
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
