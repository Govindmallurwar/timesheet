package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProjectRepository extends JpaRepository<Project, String> {
    List<Project> findByClientId(String clientId);

    @Query(
        value = """
            select p.*
            from project p
            where p.client_id in (select id from client where company_id=:companyId)
        """,
        nativeQuery = true
    )
    List<Project> findByCompanyId(@Param("companyId") String companyId);

    Optional<Project> findByIdAndClientId(String id, String clientId);
}
