package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.*;
import com.scrumconnect.timesheet.api.model.dto.ProjectEmployeeDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectEmployeeDto;
import com.scrumconnect.timesheet.api.service.EmployeeProjectRoleService;
import com.scrumconnect.timesheet.api.service.EmployeeService;
import com.scrumconnect.timesheet.api.service.ProjectEmployeeService;
import com.scrumconnect.timesheet.api.service.ProjectService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@CrossOrigin
@RequestMapping
public class ProjectEmployeeController {
    private final ProjectEmployeeService projectEmployeeService;
    private final ProjectService projectService;
    private final EmployeeService employeeService;
    private final EmployeeProjectRoleService employeeProjectRoleService;

    public ProjectEmployeeController(
            ProjectEmployeeService projectEmployeeService,
            ProjectService projectService,
            EmployeeService employeeService,
            EmployeeProjectRoleService employeeProjectRoleService) {
        this.projectEmployeeService = projectEmployeeService;
        this.projectService = projectService;
        this.employeeService = employeeService;
        this.employeeProjectRoleService = employeeProjectRoleService;
    }

//    @GetMapping
//    public ResponseEntity<List<ProjectEmployeeDto>> findAll() {
//        List<ProjectEmployeeDto> dtos = projectService.findAll().stream().map(ProjectEmployee::toDto).collect(Collectors.toList());
//
//        return ResponseEntity.ok(dtos);
//    }

    @GetMapping(
            value = "/client/{clientId}/project/{projectId}/team",
            produces = "application/json"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<ProjectEmployeeDto>> findAllByProject(@PathVariable String clientId, @PathVariable String projectId) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> {
                    // Validate project is related to client
                    Optional<Project> projectOptional = projectService.findByClientIdAndProjectId(clientId, projectId);

                    return projectOptional
                            .map(project ->
                                    ResponseEntity.ok(
                                        projectEmployeeService.findByProjectId(projectId).stream()
                                            .map(projectEmployee -> {
                                                ProjectEmployeeDto dto = projectEmployee.toDto();
                                                dto.setProject(project.toDto());
                                                setDtoEmployee(dto);
                                                setDtoEmployeeProjectRole(dto);

                                                return dto;
                                            })
                                            .collect(Collectors.toList())))
                            .orElseGet(() -> ResponseEntity.badRequest().build());
                })
                .orElseGet(() -> ResponseEntity.status(401).build()
                );
    }

    private void setDtoEmployee(ProjectEmployeeDto dto) {
        Optional<Employee> employeeOptional = employeeService.findById(dto.getEmployeeId());
        if (employeeOptional.isPresent()) {
            dto.setEmployee(employeeOptional.get().toDto());
        }
    }

    private void setDtoEmployeeProjectRole(ProjectEmployeeDto dto) {
        Optional<EmployeeProjectRole> employeeProjectRoleOptional = employeeProjectRoleService.findById(dto.getEmployeeProjectRoleId());
        if (employeeProjectRoleOptional.isPresent()) {
            dto.setEmployeeProjectRole(employeeProjectRoleOptional.get().toDto());
        }
    }

//    @GetMapping(value = "/employee/{employeeId}")
//    public ResponseEntity<List<ProjectEmployeeDto>> findAllByEmployee(@PathVariable("employeeId") String employeeId) {
//        List<ProjectEmployeeDto> dtos = projectService.findByEmployeeId(employeeId).stream().map(ProjectEmployee::toDto).collect(Collectors.toList());
//
//        return ResponseEntity.ok(dtos);
//    }

//    @GetMapping(value = "/employee-project-role/{employeeProjectRoleId}")
//    public ResponseEntity<List<ProjectEmployeeDto>> findAllByEmployeeProjectRole(@PathVariable("employeeProjectRoleId") String employeeProjectRoleId) {
//        List<ProjectEmployeeDto> dtos = projectService.findByEmployeeProjectRoleId(employeeProjectRoleId).stream().map(ProjectEmployee::toDto).collect(Collectors.toList());
//
//        return ResponseEntity.ok(dtos);
//    }

//    @GetMapping(
//            value = "/client/{clientId}/project/{projectId}/team/{id}",
//            produces = "application/json"
//    )
//    public ResponseEntity<ProjectEmployeeDto> findOne(@PathVariable("id") String id) {
//        return projectService.findOne(id)
//            .map(employeeProjectRoleId -> ResponseEntity.ok(employeeProjectRoleId.toDto()))
//            .orElseGet(() -> ResponseEntity.notFound().build());
//    }

    @PostMapping(
            value = "/client/{clientId}/project/{projectId}/team",
            consumes = "application/json",
            produces = "application/json"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity add(@PathVariable String clientId, @PathVariable String projectId, @RequestBody NewProjectEmployeeDto newProjectEmployeeDto) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> {
                    // Validate project is related to client
                    Optional<Project> projectOptional = projectService.findByClientIdAndProjectId(clientId, projectId);
                    Optional<Employee> employeeOptional = employeeService.findById(newProjectEmployeeDto.getEmployeeId());

                    if (projectOptional.isEmpty() || employeeOptional.isEmpty()) {
                        return ResponseEntity.badRequest().build();
                    }

                    return ResponseEntity.ok(
                            projectEmployeeService.save(
                                    projectOptional.get(), employeeOptional.get(), newProjectEmployeeDto
                            ).toDto()
                    );
                })
                .orElseGet(() -> ResponseEntity.status(401).build()
        );
    }

//    @DeleteMapping(value = "/{id}")
//    public ResponseEntity<Void> delete(@RequestParam("id") String id) {
//        if (projectEmployeeService.delete(id)) {
//            return ResponseEntity.ok().build();
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
}
