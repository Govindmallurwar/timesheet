package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Employee;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;
    private final EmployeeService employeeService;

    public UserService(PasswordEncoder passwordEncoder, UserRepository userRepository, EmployeeService employeeService) {
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
        this.employeeService = employeeService;
    }

//    @Autowired
//    private PasswordEncoder encoder;

    public Optional<User> findUserByEmail(String email) {
        return userRepository.findUserByEmail(email);
    }

//    public Optional<User> authenticateUser(String email, String rawPassword) {
//        Optional<User> userOption = userRepository.findUserByEmail(email);
//
//        if (userOption.isPresent() && passwordEncoder.matches(rawPassword, userOption.get().getPasswordHash())) {
//            return userOption;
//        }
//
//        return Optional.empty();
//    }

    public Optional<User> initialiseUser(String email, String rawPassword) {
        if (userRepository.count() == 0) {
            Optional<Employee> employee = employeeService.findByEmail(email);

            if (employee.isPresent()) {
                User user = new User();
                user.setId(UUID.randomUUID().toString());
                user.setEmail(email);
                user.setPasswordHash(passwordEncoder.encode(rawPassword));
                user.setRole("SA");
                user.setEmployee(employee.get());
                return Optional.of(userRepository.save(user));
            }
        }

        return Optional.empty();
    }

    public Boolean hasSystemBeenInitialised() {
        return userRepository.count() > 0;
    }
}
