package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EmployeeVacationBookedDto {
    private String id;
    private String employeeId;
    private String projectTimeUnitId;
    private LocalDateTime effectiveDate;
    private Integer units;

}
