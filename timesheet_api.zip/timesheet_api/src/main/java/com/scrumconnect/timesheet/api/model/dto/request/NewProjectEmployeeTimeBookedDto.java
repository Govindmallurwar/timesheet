package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NewProjectEmployeeTimeBookedDto {
    private String projectEmployeeId;
    private String projectTimeUnitId;
    private LocalDateTime effectiveDate;
    private Integer units;
}
