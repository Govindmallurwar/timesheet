package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Client;
import com.scrumconnect.timesheet.api.model.dto.request.NewClientDto;
import com.scrumconnect.timesheet.api.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ClientService {
    @Autowired
    private ClientRepository clientRepository;

    public List<Client> findAll() {
        return clientRepository.findAll();
    }

    public Optional<Client> findOne(String id) {
        return clientRepository.findById(id);
    }

    public Client save(Client clientToSave) {
        clientToSave.setId(UUID.randomUUID().toString());

        return clientRepository.save(clientToSave);
    }

    public Boolean delete(String id) {
        Optional<Client> clientToDelete = clientRepository.findById(id);
        clientToDelete.ifPresent(
            client -> clientRepository.delete(client)
        );

        return clientToDelete.isPresent();
    }

    public List<Client> findByCompanyId(String companyId) {
        return clientRepository.findByCompanyId(companyId);
    }
}
