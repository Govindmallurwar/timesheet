package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.ProjectTimeUnit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProjectTimeUnitRepository extends JpaRepository<ProjectTimeUnit, String> {
    List<ProjectTimeUnit> findByProjectId(String projectId);
}
