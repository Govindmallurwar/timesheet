package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.EmployeeType;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeTypeDto;
import com.scrumconnect.timesheet.api.repository.EmployeeTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class EmployeeTypeService {
    @Autowired
    private EmployeeTypeRepository employeeTypeRepository;

    public List<EmployeeType> findAll() {
        return employeeTypeRepository.findAll();
    }

    public Optional<EmployeeType> findOne(String id) {
        return employeeTypeRepository.findById(id);
    }

    public EmployeeType save(NewEmployeeTypeDto newEmployeeTypeDto) {
        EmployeeType employeeTypeToSave = new EmployeeType();
        employeeTypeToSave.setId(UUID.randomUUID().toString());
        employeeTypeToSave.setCompanyId(newEmployeeTypeDto.getCompanyId());
        employeeTypeToSave.setTitle(newEmployeeTypeDto.getTitle());

        return employeeTypeRepository.save(employeeTypeToSave);
    }

    public Boolean delete(String id) {
        Optional<EmployeeType> employeeTypeToDelete = employeeTypeRepository.findById(id);
        employeeTypeToDelete.ifPresent(
            employeeType -> employeeTypeRepository.delete(employeeType)
        );

        return employeeTypeToDelete.isPresent();
    }

    public List<EmployeeType> findByCompanyId(String companyId) {
        return employeeTypeRepository.findByCompanyId(companyId);
    }
}
