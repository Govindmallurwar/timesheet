package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.util.List;

@Data
public class CompanyDto {
    private String id;

    private String name;

    private List<ClientDto> clients;
}
