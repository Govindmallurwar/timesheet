package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

@Data
public class ProfileDto {
    private String email;
}
