package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.EmployeeDetail;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeDetailDto;
import com.scrumconnect.timesheet.api.repository.EmployeeDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class EmployeeDetailService {
    @Autowired
    private EmployeeDetailRepository employeeDetailRepository;

    public List<EmployeeDetail> findAll() {
        return employeeDetailRepository.findAll();
    }

    public Optional<EmployeeDetail> findOne(String id) {
        return employeeDetailRepository.findById(id);
    }

    public EmployeeDetail save(NewEmployeeDetailDto newEmployeeDetailDto) {
        EmployeeDetail employeeTypeToSave = new EmployeeDetail();
        employeeTypeToSave.setId(UUID.randomUUID().toString());
        employeeTypeToSave.setEmployeeId(newEmployeeDetailDto.getEmployeeId());
        employeeTypeToSave.setKeyId(newEmployeeDetailDto.getKeyId());
        employeeTypeToSave.setValue(newEmployeeDetailDto.getValue());
        employeeTypeToSave.setEffectiveDate(newEmployeeDetailDto.getEffectiveDate());

        return employeeDetailRepository.save(employeeTypeToSave);
    }

    public Boolean delete(String id) {
        Optional<EmployeeDetail> employeeDetailToDelete = employeeDetailRepository.findById(id);
        employeeDetailToDelete.ifPresent(
            employeeDetail -> employeeDetailRepository.delete(employeeDetail)
        );

        return employeeDetailToDelete.isPresent();
    }

    public List<EmployeeDetail> findByEmployeeId(String employeeId) {
        return employeeDetailRepository.findByEmployeeId(employeeId);
    }
}
