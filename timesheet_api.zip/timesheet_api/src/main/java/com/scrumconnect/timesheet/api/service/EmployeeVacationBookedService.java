package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.EmployeeVacationBooked;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeVacationBookedDto;
import com.scrumconnect.timesheet.api.repository.EmployeeVacationBookedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class EmployeeVacationBookedService {
    @Autowired
    private EmployeeVacationBookedRepository employeeDetailRepository;

    public List<EmployeeVacationBooked> findAll() {
        return employeeDetailRepository.findAll();
    }

    public Optional<EmployeeVacationBooked> findOne(String id) {
        return employeeDetailRepository.findById(id);
    }

    public EmployeeVacationBooked save(NewEmployeeVacationBookedDto newEmployeeVacationBookedDto) {
        EmployeeVacationBooked employeeTypeToSave = new EmployeeVacationBooked();
        employeeTypeToSave.setId(UUID.randomUUID().toString());
        employeeTypeToSave.setEmployeeId(newEmployeeVacationBookedDto.getEmployeeId());
        employeeTypeToSave.setProjectTimeUnitId(newEmployeeVacationBookedDto.getProjectTimeUnitId());
        employeeTypeToSave.setEffectiveDate(newEmployeeVacationBookedDto.getEffectiveDate());
        employeeTypeToSave.setUnits(newEmployeeVacationBookedDto.getUnits());

        return employeeDetailRepository.save(employeeTypeToSave);
    }

    public Boolean delete(String id) {
        Optional<EmployeeVacationBooked> employeeVacationBookedToDelete = employeeDetailRepository.findById(id);
        employeeVacationBookedToDelete.ifPresent(
            employeeVacationBooked -> employeeDetailRepository.delete(employeeVacationBooked)
        );

        return employeeVacationBookedToDelete.isPresent();
    }

    public List<EmployeeVacationBooked> findByEmployeeId(String employeeId) {
        return employeeDetailRepository.findByEmployeeId(employeeId);
    }
}
