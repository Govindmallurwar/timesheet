package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class TimesheetDto {
    Integer id;
    String companyId;
    String companyName;
    String clientId;
    String clientName;
    String projectId;
    String projectName;
    String employeeId;
    String firstName;
    String lastName;
    String projectEmployeeTimeBookedId;
    LocalDateTime effectiveDate;
    Integer bookedUnits;
    String projectEmployeeId;
    String projectTimeUnitId;
    String unit;
    Integer baseUnit;
    Integer effectiveDateYear;
    Integer effectiveDateMonth;
    Integer effectiveDateDay;
    String effectiveDateDayName;
    String effectiveDateYearWeek;
    LocalDate effectiveDateFirstDayOfWeekSunday;
    LocalDate effectiveDateFirstDayOfWeekMonday;

}
