package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

@Data
public class NewEmployeeDetailsKeyDto {
    private String companyId;
    private String detailKey;
    private String detailType;
    private Integer displayOrder;
}
