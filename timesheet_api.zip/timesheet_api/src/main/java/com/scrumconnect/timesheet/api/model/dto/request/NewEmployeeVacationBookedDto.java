package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NewEmployeeVacationBookedDto {
    private String employeeId;
    private String projectTimeUnitId;
    private LocalDateTime effectiveDate;
    private Integer units;
}
