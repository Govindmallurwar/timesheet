package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.ProjectEmployeeTimeStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectEmployeeTimeStatusRepository extends JpaRepository<ProjectEmployeeTimeStatus, String> {
}
