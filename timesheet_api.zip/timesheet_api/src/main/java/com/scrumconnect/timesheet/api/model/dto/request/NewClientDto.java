package com.scrumconnect.timesheet.api.model.dto.request;

import com.scrumconnect.timesheet.api.model.Client;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NewClientDto {
    private String name;
    private String shortCode;

    public Client toObj(String companyId) {
        Client client = new Client();

        client.setCompanyId(companyId);
        client.setName(this.getName());
        client.setShortCode(this.getShortCode());
        client.setCreatedAt(LocalDateTime.now());

        return client;
    }
}
