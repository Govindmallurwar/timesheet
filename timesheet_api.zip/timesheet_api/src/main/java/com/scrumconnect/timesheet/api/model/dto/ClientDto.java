package com.scrumconnect.timesheet.api.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class ClientDto {
    private String id;
    private String companyId;
    private String name;
    private String shortCode;
    private List<ProjectDto> projects;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
}
