package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Timesheet;
import com.scrumconnect.timesheet.api.repository.TimesheetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TimesheetService {
    @Autowired
    private TimesheetRepository timesheetRepository;

    public List<Timesheet> findTimesheetsForCompanyIdAndClientIdAndProjectId(String companyId, String clientId, String projectId) {
        return timesheetRepository.findTimesheetsByCompanyIdAndClientIdAndProjectId(companyId, clientId, projectId);
    }

    public List<Timesheet> findTimesheetsForEmployeeId(String employeeId) {
        return timesheetRepository.findTimesheetsByEmployeeId(employeeId);
    }
}
