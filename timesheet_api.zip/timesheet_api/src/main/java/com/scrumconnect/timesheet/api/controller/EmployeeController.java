package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.Employee;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.EmployeeDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeDto;
import com.scrumconnect.timesheet.api.service.EmployeeService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@CrossOrigin
@RequestMapping(path = "/employee")
public class EmployeeController {
    @Autowired
    private EmployeeService projectService;

    @GetMapping
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<EmployeeDto>> findAll() {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> {
                    List<EmployeeDto> dtos = projectService.findAll().stream().map(Employee::toDto).collect(Collectors.toList());

                    return ResponseEntity.ok(dtos);
                })
                .orElseGet(() -> ResponseEntity.status(401).build()
                );
    }

    @GetMapping(value = "/company/{companyId}")
    public ResponseEntity<List<EmployeeDto>> findAllByCompany(@PathVariable("companyId") String companyId) {
        List<EmployeeDto> dtos = projectService.findByCompanyId(companyId).stream().map(Employee::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/client/{employeeTypeId}")
    public ResponseEntity<List<EmployeeDto>> findByEmployeeType(@PathVariable("employeeTypeId") String employeeTypeId) {
        List<EmployeeDto> dtos = projectService.findByEmployeeTypeId(employeeTypeId).stream().map(Employee::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<EmployeeDto> findOne(@PathVariable("id") String id) {
        return projectService.findById(id)
            .map(employee -> ResponseEntity.ok(employee.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EmployeeDto> add(@RequestBody NewEmployeeDto newEmployeeDto) {
        return ResponseEntity.ok(projectService.save(newEmployeeDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@RequestParam("id") String id) {
        if (projectService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
