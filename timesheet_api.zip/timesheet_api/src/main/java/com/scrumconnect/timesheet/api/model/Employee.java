package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.EmployeeDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDate;

@Data
@Entity
public class Employee {
    @Id
    private String id;
    private String email;
    private String firstName;
    private String lastName;
    private String employeeTypeId;
    private String companyId;
    private LocalDate startDate;
    private LocalDate endDate;

    public EmployeeDto toDto() {
        EmployeeDto dto = new EmployeeDto();

        dto.setId(this.getId());
        dto.setEmail(this.getEmail());
        dto.setFirstName(this.getFirstName());
        dto.setLastName(this.getLastName());
        dto.setEmployeeTypeId(this.getEmployeeTypeId());
        dto.setCompanyId(this.getCompanyId());
        dto.setStartDate(this.getStartDate());
        dto.setEndDate(this.getEndDate());

        return dto;
    }
}
