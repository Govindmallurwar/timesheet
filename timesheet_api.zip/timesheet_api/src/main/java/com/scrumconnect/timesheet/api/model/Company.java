package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.CompanyDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import lombok.Data;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Entity
public class Company {
    @Id
    private String id;

    private String name;

    @OneToMany(mappedBy = "companyId")
    @OrderBy("name ASC")
    private List<Client> clients = Collections.emptyList();

    public CompanyDto toDto() {
        CompanyDto dto = new CompanyDto();

        dto.setId(this.getId());
        dto.setName(this.getName());

        dto.setClients(clients.stream().map(Client::toDto).collect(Collectors.toList()));

        return dto;
    }
}
