package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.request.AuthenticationRequestDto;
import com.scrumconnect.timesheet.api.model.dto.UserDto;
import com.scrumconnect.timesheet.api.model.dto.request.InitialiseSystemDto;
import com.scrumconnect.timesheet.api.model.dto.request.RegistrationRequestDto;
import com.scrumconnect.timesheet.api.service.AuthenticationService;
import com.scrumconnect.timesheet.api.service.JwtService;
import com.scrumconnect.timesheet.api.service.UserService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;
import java.util.function.Supplier;

@RestController
@CrossOrigin
@RequestMapping(path = "/authenticate")
public class AuthenticationController {
    private final UserService userService;
    private final JwtService jwtService;
    private final AuthenticationService authenticationService;

    public AuthenticationController(UserService userService, JwtService jwtService, AuthenticationService authenticationService) {
        this.userService = userService;
        this.jwtService = jwtService;
        this.authenticationService = authenticationService;
    }

    @GetMapping(
            value = "/initialised",
            produces = "application/json"
    )
    public ResponseEntity<Boolean> hasSystemBeenInitialised() {
        return ResponseEntity.ok(userService.hasSystemBeenInitialised());
    }

    @PostMapping(
            value = "/initialise",
            consumes = "application/json",
            produces = "application/json"
    )
    public ResponseEntity<UserDto> initialiseSystem(@RequestBody InitialiseSystemDto initialiseSystemDto) {
        return userService.initialiseUser(initialiseSystemDto.getEmail(), initialiseSystemDto.getPassword())
                .map(userDto -> ResponseEntity.status(HttpStatus.OK).body(userDto.toDto()))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }

//    @PostMapping(
//            consumes = "application/json",
//            produces = "application/json"
//    )
//    public ResponseEntity<UserDto> authenticate(@RequestBody AuthenticationRequestDto authenticationRequestDto) {
//        return userService.authenticateUser(authenticationRequestDto.getEmail(), authenticationRequestDto.getPassword())
//                .map(user -> {
//                    String jwtToken = jwtService.generateToken(user);
//
//                    return ResponseEntity.status(HttpStatus.OK).body(user.toDto());
//                })
//                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
//    }

    @PostMapping(
        consumes = "application/json",
        produces = "application/json"
    )
    @CrossOrigin
    public ResponseEntity<UserDto> authenticate(@RequestBody AuthenticationRequestDto loginUserDto) {
        try {
            User authenticatedUser = authenticationService.authenticate(loginUserDto);

            String jwtToken = jwtService.generateToken(authenticatedUser);

            UserDto loginResponse = authenticatedUser.toDto();
            loginResponse.setToken(jwtToken);
            loginResponse.setExpiresIn(jwtService.getExpirationTime());

            return ResponseEntity.ok(loginResponse);
        } catch (BadCredentialsException badCredentialsException) {
            return ResponseEntity.status(401).build();
        }
    }

    @GetMapping("/me")
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<User> authenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null) {
            return ResponseEntity.status(401).build();
        }

        return ResponseEntity.ok((User) authentication.getPrincipal());
    }


    @PostMapping(
            path = "/register",
            consumes = "application/json",
            produces = "application/json"
    )
    @CrossOrigin
    public ResponseEntity<UserDto> register(@RequestBody RegistrationRequestDto registrationRequestDto) {
        try {
            Optional<User> registeredUserOption = authenticationService.register(registrationRequestDto);

            Optional<UserDto> userDtoOptional = registeredUserOption
                    .map(registeredUser -> {
                        String jwtToken = jwtService.generateToken(registeredUser);

                        UserDto loginResponse = registeredUser.toDto();
                        loginResponse.setToken(jwtToken);
                        loginResponse.setExpiresIn(jwtService.getExpirationTime());

                        return loginResponse;
                    });

            return userDtoOptional.isPresent()
                    ? ResponseEntity.created(new URI("/employee/" + userDtoOptional.get().getId())).body(userDtoOptional.get())
                    : ResponseEntity.badRequest().build();
        } catch (BadCredentialsException badCredentialsException) {
            return ResponseEntity.status(401).build();
        } catch (URISyntaxException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
