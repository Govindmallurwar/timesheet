package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Employee;
import com.scrumconnect.timesheet.api.model.Project;
import com.scrumconnect.timesheet.api.model.ProjectEmployee;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectEmployeeDto;
import com.scrumconnect.timesheet.api.repository.ProjectEmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProjectEmployeeService {
    @Autowired
    private ProjectEmployeeRepository projectEmployeeRepository;

    public List<ProjectEmployee> findAll() {
        return projectEmployeeRepository.findAll();
    }

    public Optional<ProjectEmployee> findOne(String id) {
        return projectEmployeeRepository.findById(id);
    }

    public ProjectEmployee save(Project project, Employee employee, NewProjectEmployeeDto newProjectEmployeeDto) {
        ProjectEmployee projectToSave = new ProjectEmployee();
        projectToSave.setId(UUID.randomUUID().toString());
        projectToSave.setProjectId(project.getId());
        projectToSave.setEmployeeId(employee.getId());
        projectToSave.setEmployeeProjectRoleId(newProjectEmployeeDto.getEmployeeProjectRoleId());
        projectToSave.setStartDate(newProjectEmployeeDto.getStartDate());
        projectToSave.setEndDate(newProjectEmployeeDto.getEndDate());

        return projectEmployeeRepository.save(projectToSave);
    }

    public Boolean delete(String id) {
        Optional<ProjectEmployee> projectEmployeeToDelete = projectEmployeeRepository.findById(id);
        projectEmployeeToDelete.ifPresent(
            projectEmployee -> projectEmployeeRepository.delete(projectEmployee)
        );

        return projectEmployeeToDelete.isPresent();
    }

    public List<ProjectEmployee> findByProjectId(String projectId) {
        return projectEmployeeRepository.findByProjectId(projectId);
    }

    public List<ProjectEmployee> findByEmployeeId(String employeeId) {
        return projectEmployeeRepository.findByEmployeeId(employeeId);
    }

    public List<ProjectEmployee> findByEmployeeProjectRoleId(String employeeProjectRoleId) {
        return projectEmployeeRepository.findByEmployeeProjectRoleId(employeeProjectRoleId);
    }
}
