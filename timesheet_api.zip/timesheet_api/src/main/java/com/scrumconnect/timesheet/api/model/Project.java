package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.ProjectDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Entity
public class Project {
    @Id
    private String id;
    private String clientId;
    private String name;
    private String poNumber;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    @OneToMany(mappedBy = "projectId")
    private List<ProjectEmployee> projectEmployees = Collections.EMPTY_LIST;

    public ProjectDto toDto() {
        ProjectDto dto = new ProjectDto();

        dto.setId(this.getId());
        dto.setClientId(this.getClientId());
        dto.setName(this.getName());
        dto.setPoNumber(this.getPoNumber());
        dto.setStartDate(this.getStartDate());
        dto.setEndDate(this.getEndDate());

        dto.setProjectEmployees(projectEmployees.stream().map(ProjectEmployee::toDto).collect(Collectors.toList()));

        return dto;
    }
}
