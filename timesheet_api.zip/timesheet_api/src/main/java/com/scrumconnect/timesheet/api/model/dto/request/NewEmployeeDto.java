package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

import java.time.LocalDate;

@Data
public class NewEmployeeDto {
    private String email;
    private String firstName;
    private String lastName;
    private String employeeTypeId;
    private String companyId;
    private LocalDate startDate;
    private LocalDate endDate;
}
