package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Project;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectDto;
import com.scrumconnect.timesheet.api.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProjectService {
    @Autowired
    private ProjectRepository projectRepository;

    public List<Project> findAll() {
        return projectRepository.findAll();
    }

    public Optional<Project> findOne(String id) {
        return projectRepository.findById(id);
    }

    public Project save(String clientId, NewProjectDto newProjectDto) {
        Project projectToSave = new Project();
        projectToSave.setId(UUID.randomUUID().toString());
        projectToSave.setClientId(clientId);
        projectToSave.setName(newProjectDto.getName());
        projectToSave.setPoNumber(newProjectDto.getPoNumber());
        projectToSave.setStartDate(newProjectDto.getStartDate());
        projectToSave.setEndDate(newProjectDto.getEndDate());

        return projectRepository.save(projectToSave);
    }

    public Boolean delete(String id) {
        Optional<Project> projectToDelete = projectRepository.findById(id);
        projectToDelete.ifPresent(
            project -> projectRepository.delete(project)
        );

        return projectToDelete.isPresent();
    }

    public List<Project> findByCompanyId(String companyId) {
        return projectRepository.findByCompanyId(companyId);
    }

    public List<Project> findByClientId(String clientId) {
        return projectRepository.findByClientId(clientId);
    }

    public Optional<Project> findById(String projectId) {
        return projectRepository.findById(projectId);
    }

    public Optional<Project> findByClientIdAndProjectId(String clientId, String projectId) {
        return projectRepository.findByIdAndClientId(projectId, clientId);
    }
}
