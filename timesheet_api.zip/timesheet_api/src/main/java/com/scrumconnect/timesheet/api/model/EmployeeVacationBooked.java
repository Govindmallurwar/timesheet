package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.EmployeeVacationBookedDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
public class EmployeeVacationBooked {
    @Id
    private String id;
    private String employeeId;
    private String projectTimeUnitId;
    private LocalDateTime effectiveDate;
    private Integer units;


    public EmployeeVacationBookedDto toDto() {
        EmployeeVacationBookedDto dto = new EmployeeVacationBookedDto();

        dto.setId(this.getId());
        dto.setEmployeeId(this.getEmployeeId());
        dto.setProjectTimeUnitId(this.getProjectTimeUnitId());
        dto.setEffectiveDate(this.getEffectiveDate());
        dto.setUnits(this.getUnits());

        return dto;
    }
}
