package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.EmployeeDetailsKey;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeDetailsKeyDto;
import com.scrumconnect.timesheet.api.repository.EmployeeDetailsKeyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class EmployeeDetailsKeyService {
    @Autowired
    private EmployeeDetailsKeyRepository employeeDetailsKeyRepository;

    public List<EmployeeDetailsKey> findAll() {
        return employeeDetailsKeyRepository.findAll();
    }

    public Optional<EmployeeDetailsKey> findOne(String id) {
        return employeeDetailsKeyRepository.findById(id);
    }

    public EmployeeDetailsKey save(NewEmployeeDetailsKeyDto newEmployeeTypeDto) {
        EmployeeDetailsKey employeeDetailsKeyToSave = new EmployeeDetailsKey();
        employeeDetailsKeyToSave.setId(UUID.randomUUID().toString());
        employeeDetailsKeyToSave.setCompanyId(newEmployeeTypeDto.getCompanyId());
        employeeDetailsKeyToSave.setDetailKey(newEmployeeTypeDto.getDetailKey());
        employeeDetailsKeyToSave.setDetailType(newEmployeeTypeDto.getDetailType());

        return employeeDetailsKeyRepository.save(employeeDetailsKeyToSave);
    }

    public Boolean delete(String id) {
        Optional<EmployeeDetailsKey> employeeDetailsKeyToDelete = employeeDetailsKeyRepository.findById(id);
        employeeDetailsKeyToDelete.ifPresent(
            employeeDetailsKey -> employeeDetailsKeyRepository.delete(employeeDetailsKey)
        );

        return employeeDetailsKeyToDelete.isPresent();
    }

    public List<EmployeeDetailsKey> findByCompanyId(String companyId) {
        return employeeDetailsKeyRepository.findByCompanyId(companyId);
    }
}
