package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.EmployeeDetail;
import com.scrumconnect.timesheet.api.model.dto.EmployeeDetailDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeDetailDto;
import com.scrumconnect.timesheet.api.service.EmployeeDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping(path = "/employee-detail")
public class EmployeeDetailController {
    @Autowired
    private EmployeeDetailService employeeDetailService;

    @GetMapping
    public ResponseEntity<List<EmployeeDetailDto>> findAll() {
        List<EmployeeDetailDto> dtos = employeeDetailService.findAll().stream().map(EmployeeDetail::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/company/{employeeId}")
    public ResponseEntity<List<EmployeeDetailDto>> findAllByCompany(@PathVariable("employeeId") String employeeId) {
        List<EmployeeDetailDto> dtos = employeeDetailService.findByEmployeeId(employeeId).stream().map(EmployeeDetail::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<EmployeeDetailDto> findOne(@PathVariable("id") String id) {
        return employeeDetailService.findOne(id)
            .map(employeeDetail -> ResponseEntity.ok(employeeDetail.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EmployeeDetailDto> add(@RequestBody NewEmployeeDetailDto newEmployeeDetailDto) {
        return ResponseEntity.ok(employeeDetailService.save(newEmployeeDetailDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (employeeDetailService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
