package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.EmployeeProjectRole;
import com.scrumconnect.timesheet.api.model.Project;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.EmployeeProjectRoleDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeProjectRoleDto;
import com.scrumconnect.timesheet.api.service.EmployeeProjectRoleService;
import com.scrumconnect.timesheet.api.service.ProjectService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@CrossOrigin
public class EmployeeProjectRoleController {
    private final EmployeeProjectRoleService employeeProjectRoleService;
    private final ProjectService projectService;

    public EmployeeProjectRoleController(EmployeeProjectRoleService employeeProjectRoleService,
                                      ProjectService projectService) {
        this.employeeProjectRoleService = employeeProjectRoleService;
        this.projectService = projectService;
    }

    @GetMapping(
            value = "/client/{clientId}/project/{projectId}/team/role"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<EmployeeProjectRoleDto>> findAllByClientProject(@PathVariable String clientId, @PathVariable String projectId) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> {
                            // Validate project is related to client
                            Optional<Project> projectOptional = projectService.findByClientIdAndProjectId(clientId, projectId);

                            return projectOptional
                                    .map(project -> {
                                        List<EmployeeProjectRoleDto> dtos = employeeProjectRoleService.findAll().stream().map(EmployeeProjectRole::toDto).collect(Collectors.toList());

                                        return ResponseEntity.ok(dtos);
                                    })
                                    .orElseGet(() -> ResponseEntity.notFound().build());
                })
                .orElseGet(() -> ResponseEntity.status(401).build()
                );
    }

//    @GetMapping(value = "/company/{companyId}")
//    public ResponseEntity<List<EmployeeProjectRoleDto>> findAllByCompany(@PathVariable("companyId") String companyId) {
//        List<EmployeeProjectRoleDto> dtos = employeeProjectRoleService.findByCompanyId(companyId).stream().map(EmployeeProjectRole::toDto).collect(Collectors.toList());
//
//        return ResponseEntity.ok(dtos);
//    }
//
//    @GetMapping(value = "/{id}")
//    public ResponseEntity<EmployeeProjectRoleDto> findOne(@PathVariable("id") String id) {
//        return employeeProjectRoleService.findOne(id)
//            .map(employeeProjectRole -> ResponseEntity.ok(employeeProjectRole.toDto()))
//            .orElseGet(() -> ResponseEntity.notFound().build());
//    }

    @PostMapping(
            value = "/client/{clientId}/project/{projectId}/role"
    )
    public ResponseEntity<EmployeeProjectRoleDto> add(@PathVariable String clientId, @PathVariable String projectId, @RequestBody NewEmployeeProjectRoleDto newEmployeeProjectRoleDto) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> {
                    // Validate project is related to client
                    Optional<Project> projectOptional = projectService.findByClientIdAndProjectId(clientId, projectId);

                    return projectOptional
                            .map(project -> ResponseEntity.ok(employeeProjectRoleService.save(projectId, newEmployeeProjectRoleDto).toDto()))
                            .orElseGet(() -> ResponseEntity.notFound().build());
                })
                .orElseGet(() -> ResponseEntity.status(401).build()
                );
    }

//    @DeleteMapping(value = "/{id}")
//    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
//        if (employeeProjectRoleService.delete(id)) {
//            return ResponseEntity.ok().build();
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
}
