package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NewEmployeeDetailDto {
    private String employeeId;
    private String keyId;
    private String value;
    private LocalDateTime effectiveDate;
}
