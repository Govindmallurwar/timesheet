package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.EmployeeProjectRole;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeProjectRoleDto;
import com.scrumconnect.timesheet.api.repository.EmployeeProjectRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class EmployeeProjectRoleService {
    @Autowired
    private EmployeeProjectRoleRepository employeeProjectRoleRepository;

    public List<EmployeeProjectRole> findAll() {
        return employeeProjectRoleRepository.findAll();
    }

    public Optional<EmployeeProjectRole> findById(String id) {
        return employeeProjectRoleRepository.findById(id);
    }

    public EmployeeProjectRole save(String projectId, NewEmployeeProjectRoleDto newEmployeeProjectRoleDto) {
        EmployeeProjectRole employeeProjectRoleToSave = new EmployeeProjectRole();
        employeeProjectRoleToSave.setId(UUID.randomUUID().toString());
        employeeProjectRoleToSave.setProjectId(projectId);
        employeeProjectRoleToSave.setTitle(newEmployeeProjectRoleDto.getTitle());
        employeeProjectRoleToSave.setShortCode(newEmployeeProjectRoleDto.getShortCode());
        employeeProjectRoleToSave.setDisplayOrder(newEmployeeProjectRoleDto.getDisplayOrder());

        return employeeProjectRoleRepository.save(employeeProjectRoleToSave);
    }

    public Boolean delete(String id) {
        Optional<EmployeeProjectRole> employeeProjectRoleToDelete = employeeProjectRoleRepository.findById(id);
        employeeProjectRoleToDelete.ifPresent(
            employeeProjectRole -> employeeProjectRoleRepository.delete(employeeProjectRole)
        );

        return employeeProjectRoleToDelete.isPresent();
    }
//
//    public List<EmployeeProjectRole> findByCompanyId(String companyId) {
//        return employeeProjectRoleRepository.findByCompanyId(companyId);
//    }
}
