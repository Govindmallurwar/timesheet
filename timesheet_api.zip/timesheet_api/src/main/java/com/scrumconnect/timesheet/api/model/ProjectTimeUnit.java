package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.ProjectTimeUnitDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDate;

@Data
@Entity
public class ProjectTimeUnit {
    @Id
    private String id;

    private String projectId;
    private LocalDate effectiveDate;
    private String unit;
    private Integer baseUnit;

    public ProjectTimeUnitDto toDto() {
        ProjectTimeUnitDto dto = new ProjectTimeUnitDto();

        dto.setId(this.getId());
        dto.setProjectId(this.getProjectId());
        dto.setEffectiveDate(this.getEffectiveDate());
        dto.setUnit(this.getUnit());
        dto.setBaseUnit(this.getBaseUnit());

        return dto;
    }
}
