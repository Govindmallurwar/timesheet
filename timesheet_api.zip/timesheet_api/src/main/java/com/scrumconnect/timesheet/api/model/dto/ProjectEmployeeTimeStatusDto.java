package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ProjectEmployeeTimeStatusDto {
    private String id;
    private String projectEmployeeId;
    private String projectEmployeeTimeBookedId;
    private String projectTimeUnitId;
    private String state;
    private String notes;
    private LocalDateTime notesDate;
}
