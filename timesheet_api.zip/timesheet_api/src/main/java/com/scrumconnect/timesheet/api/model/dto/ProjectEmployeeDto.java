package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ProjectEmployeeDto {
    private String id;
    private String projectId;
    private ProjectDto project;
    private String employeeId;
    private EmployeeDto employee;
    private String employeeProjectRoleId;
    private EmployeeProjectRoleDto employeeProjectRole;
    private LocalDate startDate;
    private LocalDate endDate;
}
