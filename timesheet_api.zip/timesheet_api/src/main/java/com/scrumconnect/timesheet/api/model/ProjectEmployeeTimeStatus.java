package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.ProjectEmployeeTimeStatusDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
public class ProjectEmployeeTimeStatus {
    @Id
    private String id;
    private String projectEmployeeId;
    private String projectEmployeeTimeBookedId;
    private String projectTimeUnitId;
    private String state;
    private String notes;
    private LocalDateTime notesDate;

    public ProjectEmployeeTimeStatusDto toDto() {
        ProjectEmployeeTimeStatusDto dto = new ProjectEmployeeTimeStatusDto();

        dto.setId(this.getId());
        dto.setProjectEmployeeId(this.getProjectEmployeeId());
        dto.setProjectTimeUnitId(this.getProjectTimeUnitId());
        dto.setProjectEmployeeTimeBookedId(this.getProjectEmployeeTimeBookedId());
        dto.setState(this.getState());
        dto.setNotes(this.getNotes());
        dto.setNotesDate(this.getNotesDate());

        return dto;
    }
}
