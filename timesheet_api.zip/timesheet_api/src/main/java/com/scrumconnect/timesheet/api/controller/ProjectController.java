package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.Project;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.ProjectDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectDto;
import com.scrumconnect.timesheet.api.service.ProjectService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@CrossOrigin
@RequestMapping(path = "/client/{clientId}/project")
public class ProjectController {
    private final ProjectService projectService;

    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

//    @GetMapping
//    @SecurityRequirement(name = "Bearer Authentication")
//    public ResponseEntity<List<ProjectDto>> findAll() {
//        List<ProjectDto> dtos = projectService.findAll().stream().map(Project::toDto).collect(Collectors.toList());
//
//        return ResponseEntity.ok(dtos);
//    }
//
//    @GetMapping(value = "/company/{companyId}")
//    public ResponseEntity<List<ProjectDto>> findAllByCompany(@PathVariable("companyId") String companyId) {
//        List<ProjectDto> dtos = projectService.findByCompanyId(companyId).stream().map(Project::toDto).collect(Collectors.toList());
//
//        return ResponseEntity.ok(dtos);
//    }
//
//    @GetMapping(value = "/client/{clientId}")
//    public ResponseEntity<List<ProjectDto>> findAllByClient(@PathVariable("clientId") String clientId) {
//        List<ProjectDto> dtos = projectService.findByClientId(clientId).stream().map(Project::toDto).collect(Collectors.toList());
//
//        return ResponseEntity.ok(dtos);
//    }

    @GetMapping(value = "/{id}")
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<ProjectDto> findOne(@PathVariable("id") String id) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> projectService.findOne(id)
                        .map(project -> ResponseEntity.ok(project.toDto()))
                        .orElseGet(() -> ResponseEntity.notFound().build()))
                .orElseGet(() ->
                        ResponseEntity.status(401).build()
                );
    }

    @PostMapping(
            produces = "application/json"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<ProjectDto> add(@RequestBody NewProjectDto newProjectDto, @PathVariable String clientId) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> ResponseEntity.ok(projectService.save(clientId, newProjectDto).toDto()))
                .orElseGet(() ->
                        ResponseEntity.status(401).build()
                );
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@RequestParam("id") String id) {
        if (projectService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
