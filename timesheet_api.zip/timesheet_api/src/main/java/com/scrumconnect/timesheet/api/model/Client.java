package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.ClientDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Entity
public class Client {
    @Id
    private String id;
    private String companyId;
    private String name;
    private String shortCode;
    @OneToMany(mappedBy = "clientId")
    @OrderBy("startDate ASC")
    private List<Project> projects = Collections.emptyList();

    private LocalDateTime createdAt;

    public ClientDto toDto() {
        ClientDto dto = new ClientDto();

        dto.setId(this.getId());
        dto.setCompanyId(this.getCompanyId());
        dto.setName(this.getName());
        dto.setShortCode(this.getShortCode());

        dto.setProjects(projects.stream().map(Project::toDto).collect(Collectors.toList()));

        dto.setCreatedAt(this.getCreatedAt());

        return dto;
    }
}
