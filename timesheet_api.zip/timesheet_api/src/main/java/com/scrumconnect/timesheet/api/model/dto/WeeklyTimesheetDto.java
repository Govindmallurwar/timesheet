package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class WeeklyTimesheetDto {
    private LocalDate weekStartDate;
    private String employeeId;
    private List<TimesheetDto> timesheets;
    private String projectName;
    private String projectShortName;
    private String status;
    private EmployeeDto approver;

}
