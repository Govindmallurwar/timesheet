package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Employee;
import com.scrumconnect.timesheet.api.model.EmployeeType;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeDto;
import com.scrumconnect.timesheet.api.repository.EmployeeRepository;
import com.scrumconnect.timesheet.api.repository.EmployeeTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class EmployeeService {
    private final EmployeeRepository employeeRepository;
    private final EmployeeTypeRepository employeeTypeRepository;

    public EmployeeService(EmployeeRepository employeeRepository,
                           EmployeeTypeRepository employeeTypeRepository) {
        this.employeeRepository = employeeRepository;
        this.employeeTypeRepository = employeeTypeRepository;
    }

    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> findById(String id) {
        return employeeRepository.findById(id);
    }

    public Employee save(NewEmployeeDto newEmployeeDto) {
        Employee employeeToSave = new Employee();
        employeeToSave.setId(UUID.randomUUID().toString());
        employeeToSave.setCompanyId(newEmployeeDto.getCompanyId());
        employeeToSave.setEmployeeTypeId(newEmployeeDto.getEmployeeTypeId());
        employeeToSave.setEmail(newEmployeeDto.getEmail());
        employeeToSave.setFirstName(newEmployeeDto.getFirstName());
        employeeToSave.setLastName(newEmployeeDto.getLastName());
        employeeToSave.setStartDate(newEmployeeDto.getStartDate() == null ? LocalDate.now() : newEmployeeDto.getStartDate());
        employeeToSave.setEndDate(newEmployeeDto.getEndDate());

        return employeeRepository.save(employeeToSave);
    }

    public Boolean delete(String id) {
        Optional<Employee> employeeToDelete = employeeRepository.findById(id);
        employeeToDelete.ifPresent(
            employee -> employeeRepository.delete(employee)
        );

        return employeeToDelete.isPresent();
    }

    public List<Employee> findByCompanyId(String companyId) {
        return employeeRepository.findByCompanyId(companyId);
    }

    public List<Employee> findByEmployeeTypeId(String clientId) {
        return employeeRepository.findByEmployeeTypeId(clientId);
    }

    public Optional<Employee> findByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }

    public Optional<EmployeeType> findEmployeeType(String companyId, String employeeTypeTitle) {
        return employeeTypeRepository.findByCompanyIdAndTitle(companyId, employeeTypeTitle);
    }
}
