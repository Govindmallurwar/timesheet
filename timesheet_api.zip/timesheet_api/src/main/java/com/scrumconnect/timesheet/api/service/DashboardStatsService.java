package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.DashboardStatsOverview;
import com.scrumconnect.timesheet.api.model.ProjectEmployee;
import com.scrumconnect.timesheet.api.model.User;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DashboardStatsService {
    private final ProjectEmployeeService projectEmployeeService;

    public DashboardStatsService(ProjectEmployeeService projectEmployeeService) {
        this.projectEmployeeService = projectEmployeeService;
    }

    public DashboardStatsOverview getOverview(User principal) {
        DashboardStatsOverview overview = new DashboardStatsOverview();

        List<ProjectEmployee> employeeProjects = projectEmployeeService.findByEmployeeId(principal.getEmployee().getId());
        overview.setProjectCount(employeeProjects.size());

        return overview;
    }
}
