package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.EmployeeDetailDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
public class EmployeeDetail {
    @Id
    private String id;
    private String employeeId;
    private String keyId;
    private String value;
    private LocalDateTime effectiveDate;


    public EmployeeDetailDto toDto() {
        EmployeeDetailDto dto = new EmployeeDetailDto();

        dto.setId(this.getId());
        dto.setEmployeeId(this.getEmployeeId());
        dto.setKeyId(this.getKeyId());
        dto.setValue(this.getValue());
        dto.setEffectiveDate(this.getEffectiveDate());

        return dto;
    }
}
