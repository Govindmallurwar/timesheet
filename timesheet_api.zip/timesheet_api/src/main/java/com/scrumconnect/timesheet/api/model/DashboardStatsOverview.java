package com.scrumconnect.timesheet.api.model;

import lombok.Data;

@Data
public class DashboardStatsOverview {
    private Integer projectCount;
}
