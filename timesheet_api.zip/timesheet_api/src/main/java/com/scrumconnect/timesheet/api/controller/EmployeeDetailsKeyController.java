package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.EmployeeDetailsKey;
import com.scrumconnect.timesheet.api.model.dto.EmployeeDetailsKeyDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeDetailsKeyDto;
import com.scrumconnect.timesheet.api.service.EmployeeDetailsKeyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping(path = "/employee-details-key")
public class EmployeeDetailsKeyController {
    @Autowired
    private EmployeeDetailsKeyService employeeDetailsKeyService;

    @GetMapping
    public ResponseEntity<List<EmployeeDetailsKeyDto>> findAll() {
        List<EmployeeDetailsKeyDto> dtos = employeeDetailsKeyService.findAll().stream().map(EmployeeDetailsKey::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/company/{companyId}")
    public ResponseEntity<List<EmployeeDetailsKeyDto>> findAllByCompany(@PathVariable("companyId") String companyId) {
        List<EmployeeDetailsKeyDto> dtos = employeeDetailsKeyService.findByCompanyId(companyId).stream().map(EmployeeDetailsKey::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<EmployeeDetailsKeyDto> findOne(@PathVariable("id") String id) {
        return employeeDetailsKeyService.findOne(id)
            .map(employeeDetailsKey -> ResponseEntity.ok(employeeDetailsKey.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EmployeeDetailsKeyDto> add(@RequestBody NewEmployeeDetailsKeyDto newEmployeeDetailsKeyDto) {
        return ResponseEntity.ok(employeeDetailsKeyService.save(newEmployeeDetailsKeyDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (employeeDetailsKeyService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
