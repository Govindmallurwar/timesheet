package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Company;
import com.scrumconnect.timesheet.api.model.Employee;
import com.scrumconnect.timesheet.api.model.EmployeeType;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.request.AuthenticationRequestDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeDto;
import com.scrumconnect.timesheet.api.model.dto.request.RegistrationRequestDto;
import com.scrumconnect.timesheet.api.repository.UserRepository;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class AuthenticationService {
    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;

    private final AuthenticationManager authenticationManager;
    private final EmployeeService employeeService;
    private final CompanyService companyService;

    public AuthenticationService(
            UserRepository userRepository,
            AuthenticationManager authenticationManager,
            PasswordEncoder passwordEncoder,
            EmployeeService employeeService,
            CompanyService companyService
    ) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.employeeService = employeeService;
        this.companyService = companyService;
    }

//    public User signup(RegisterUserDto input) {
//        User user = new User()
//                .setFullName(input.getFullName())
//                .setEmail(input.getEmail())
//                .setPassword(passwordEncoder.encode(input.getPassword()));
//
//        return userRepository.save(user);
//    }

    public User authenticate(AuthenticationRequestDto input) throws BadCredentialsException {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        input.getEmail(),
                        input.getPassword()
                )
        );

        return userRepository.findUserByEmail(input.getEmail())
                .orElseThrow();
    }

    public Optional<User> register(RegistrationRequestDto registrationRequestDto) {
        Optional<Company> companyOptional = companyService.findByName(registrationRequestDto.getCompanyName());

        Optional<EmployeeType> employeeTypeOptional = employeeService.findEmployeeType(
                companyOptional.get().getId(),
                registrationRequestDto.getEmployeeType()
        );

        if (userDoesNotExist(registrationRequestDto) &&
                employeeDoesNotExist(registrationRequestDto) &&
                (companyOptional.isPresent() && employeeTypeOptional.isPresent())
        ) {
            // Continue as user not previously registered and employee doesn't already exist
            Employee savedEmployee = createEmployee(registrationRequestDto, companyOptional.get(), employeeTypeOptional.get());

            User savedUser = createUser(registrationRequestDto, savedEmployee);

            return Optional.of(savedUser);
        } else {
            return Optional.empty();
        }
    }

    private boolean employeeDoesNotExist(RegistrationRequestDto registrationRequestDto) {
        return !employeeService.findByEmail(registrationRequestDto.getEmail()).isPresent();
    }

    private boolean userDoesNotExist(RegistrationRequestDto registrationRequestDto) {
        return !userRepository.findUserByEmail(registrationRequestDto.getEmail()).isPresent();
    }

    private User createUser(RegistrationRequestDto registrationRequestDto, Employee savedEmployee) {
        User userToSave = new User();
        userToSave.setId(UUID.randomUUID().toString());
        userToSave.setEmployee(savedEmployee);
        userToSave.setEmail(registrationRequestDto.getEmail());
        userToSave.setPasswordHash(passwordEncoder.encode(registrationRequestDto.getPassword()));
        User savedUser = userRepository.save(userToSave);
        return savedUser;
    }

    private Employee createEmployee(RegistrationRequestDto registrationRequestDto, Company company, EmployeeType employeeType) {
        NewEmployeeDto employeeDto = new NewEmployeeDto();
        employeeDto.setFirstName(registrationRequestDto.getFirstName());
        employeeDto.setLastName(registrationRequestDto.getLastName());
        employeeDto.setEmail(registrationRequestDto.getEmail());
        employeeDto.setCompanyId(company.getId());
        employeeDto.setEmployeeTypeId(employeeType.getId());

        return employeeService.save(employeeDto);
    }
}
