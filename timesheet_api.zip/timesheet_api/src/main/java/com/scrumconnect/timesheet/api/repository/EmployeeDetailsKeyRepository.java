package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.EmployeeDetailsKey;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeDetailsKeyRepository extends JpaRepository<EmployeeDetailsKey, String> {
    List<EmployeeDetailsKey> findByCompanyId(String companyId);
}
