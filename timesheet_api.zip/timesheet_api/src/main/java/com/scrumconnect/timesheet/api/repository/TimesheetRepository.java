package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.Timesheet;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TimesheetRepository extends JpaRepository<Timesheet, String> {
    List<Timesheet> findTimesheetsByCompanyIdAndClientIdAndProjectId(String companyId, String clientId, String projectId);
    List<Timesheet> findTimesheetsByEmployeeId(String employeeId);
}
