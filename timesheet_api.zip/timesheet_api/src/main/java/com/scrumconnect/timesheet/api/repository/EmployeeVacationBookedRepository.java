package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.EmployeeVacationBooked;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeVacationBookedRepository extends JpaRepository<EmployeeVacationBooked, String> {
    List<EmployeeVacationBooked> findByEmployeeId(String employeeId);
}
