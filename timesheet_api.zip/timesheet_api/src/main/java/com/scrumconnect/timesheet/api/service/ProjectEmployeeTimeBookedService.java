package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.ProjectEmployeeTimeBooked;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectEmployeeTimeBookedDto;
import com.scrumconnect.timesheet.api.repository.ProjectEmployeeTimeBookedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProjectEmployeeTimeBookedService {
    @Autowired
    private ProjectEmployeeTimeBookedRepository employeeDetailRepository;

    public List<ProjectEmployeeTimeBooked> findAll() {
        return employeeDetailRepository.findAll();
    }

    public Optional<ProjectEmployeeTimeBooked> findOne(String id) {
        return employeeDetailRepository.findById(id);
    }

    public ProjectEmployeeTimeBooked save(NewProjectEmployeeTimeBookedDto newProjectEmployeeTimeBookedDto) {
        ProjectEmployeeTimeBooked employeeTypeToSave = new ProjectEmployeeTimeBooked();
        employeeTypeToSave.setId(UUID.randomUUID().toString());
        employeeTypeToSave.setProjectEmployeeId(newProjectEmployeeTimeBookedDto.getProjectEmployeeId());
        employeeTypeToSave.setProjectTimeUnitId(newProjectEmployeeTimeBookedDto.getProjectTimeUnitId());
        employeeTypeToSave.setEffectiveDate(newProjectEmployeeTimeBookedDto.getEffectiveDate());
        employeeTypeToSave.setUnits(newProjectEmployeeTimeBookedDto.getUnits());

        return employeeDetailRepository.save(employeeTypeToSave);
    }

    public Boolean delete(String id) {
        Optional<ProjectEmployeeTimeBooked> projectEmployeeTimeBookedToDelete = employeeDetailRepository.findById(id);
        projectEmployeeTimeBookedToDelete.ifPresent(
            projectEmployeeTimeBooked -> employeeDetailRepository.delete(projectEmployeeTimeBooked)
        );

        return projectEmployeeTimeBookedToDelete.isPresent();
    }

    public List<ProjectEmployeeTimeBooked> findByProjectEmployeeId(String employeeId) {
        return employeeDetailRepository.findByProjectEmployeeId(employeeId);
    }
}
