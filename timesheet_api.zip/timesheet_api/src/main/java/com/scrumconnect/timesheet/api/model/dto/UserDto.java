package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class UserDto {
    private UUID id;
    private String role;
    private String email;
    private String avatar;

    private String token;

    private long expiresIn;
    private EmployeeDto employee;

    private CompanyDto company;

    public String getToken() {
        return token;
    }
}
