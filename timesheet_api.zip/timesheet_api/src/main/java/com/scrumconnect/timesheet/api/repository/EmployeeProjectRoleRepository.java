package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.EmployeeProjectRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeProjectRoleRepository extends JpaRepository<EmployeeProjectRole, String> {
//    List<EmployeeProjectRole> findByCompanyId(String companyId);
}
