package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class EmployeeDto {
    private String id;
    private String email;
    private String firstName;
    private String lastName;
    private String employeeTypeId;
    private String companyId;
    private LocalDate startDate;
    private LocalDate endDate;
}
