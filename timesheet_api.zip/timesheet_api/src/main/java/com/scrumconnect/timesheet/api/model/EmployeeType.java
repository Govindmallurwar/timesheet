package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.EmployeeTypeDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class EmployeeType {
    @Id
    private String id;
    private String companyId;
    private String title;
    private Integer displayOrder;


    public EmployeeTypeDto toDto() {
        EmployeeTypeDto dto = new EmployeeTypeDto();

        dto.setId(this.getId());
        dto.setCompanyId(this.getCompanyId());
        dto.setTitle(this.getTitle());
        dto.setDisplayOrder(this.getDisplayOrder());

        return dto;
    }
}
