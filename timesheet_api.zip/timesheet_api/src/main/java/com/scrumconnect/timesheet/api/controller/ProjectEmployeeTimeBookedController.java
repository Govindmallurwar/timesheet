package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.ProjectEmployeeTimeBooked;
import com.scrumconnect.timesheet.api.model.dto.ProjectEmployeeTimeBookedDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectEmployeeTimeBookedDto;
import com.scrumconnect.timesheet.api.service.ProjectEmployeeTimeBookedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping(path = "/project-employee-time-booked")
public class ProjectEmployeeTimeBookedController {
    @Autowired
    private ProjectEmployeeTimeBookedService projectEmployeeTimeBookedService;

    @GetMapping
    public ResponseEntity<List<ProjectEmployeeTimeBookedDto>> findAll() {
        List<ProjectEmployeeTimeBookedDto> dtos = projectEmployeeTimeBookedService.findAll().stream().map(ProjectEmployeeTimeBooked::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/employee/{projectEmployeeId}")
    public ResponseEntity<List<ProjectEmployeeTimeBookedDto>> findAllByProjectEmployeeId(@PathVariable("projectEmployeeId") String projectEmployeeId) {
        List<ProjectEmployeeTimeBookedDto> dtos = projectEmployeeTimeBookedService.findByProjectEmployeeId(projectEmployeeId).stream().map(ProjectEmployeeTimeBooked::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<ProjectEmployeeTimeBookedDto> findOne(@PathVariable("id") String id) {
        return projectEmployeeTimeBookedService.findOne(id)
            .map(employeeVacationBooked -> ResponseEntity.ok(employeeVacationBooked.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ProjectEmployeeTimeBookedDto> add(@RequestBody NewProjectEmployeeTimeBookedDto newProjectEmployeeTimeBookedDto) {
        return ResponseEntity.ok(projectEmployeeTimeBookedService.save(newProjectEmployeeTimeBookedDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (projectEmployeeTimeBookedService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
