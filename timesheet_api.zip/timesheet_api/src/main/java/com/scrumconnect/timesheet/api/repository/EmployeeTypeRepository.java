package com.scrumconnect.timesheet.api.repository;

import com.scrumconnect.timesheet.api.model.EmployeeType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeTypeRepository extends JpaRepository<EmployeeType, String> {
    List<EmployeeType> findByCompanyId(String companyId);

    Optional<EmployeeType> findByCompanyIdAndTitle(String companyId, String employeeTypeTitle);
}
