package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.EmployeeVacationBooked;
import com.scrumconnect.timesheet.api.model.dto.EmployeeVacationBookedDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeVacationBookedDto;
import com.scrumconnect.timesheet.api.service.EmployeeVacationBookedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping(path = "/employee-vacation-booked")
public class EmployeeVacationBookedController {
    @Autowired
    private EmployeeVacationBookedService employeeVacationBookedService;

    @GetMapping
    public ResponseEntity<List<EmployeeVacationBookedDto>> findAll() {
        List<EmployeeVacationBookedDto> dtos = employeeVacationBookedService.findAll().stream().map(EmployeeVacationBooked::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/employee/{employeeId}")
    public ResponseEntity<List<EmployeeVacationBookedDto>> findAllByEmployeeId(@PathVariable("employeeId") String employeeId) {
        List<EmployeeVacationBookedDto> dtos = employeeVacationBookedService.findByEmployeeId(employeeId).stream().map(EmployeeVacationBooked::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<EmployeeVacationBookedDto> findOne(@PathVariable("id") String id) {
        return employeeVacationBookedService.findOne(id)
            .map(employeeVacationBooked -> ResponseEntity.ok(employeeVacationBooked.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EmployeeVacationBookedDto> add(@RequestBody NewEmployeeVacationBookedDto newEmployeeVacationBookedDto) {
        return ResponseEntity.ok(employeeVacationBookedService.save(newEmployeeVacationBookedDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (employeeVacationBookedService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
