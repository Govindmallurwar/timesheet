package com.scrumconnect.timesheet.api.model.dto;

import lombok.Data;

@Data
public class EmployeeProjectRoleDto {
    private String id;
    private String projectId;
    private String title;
    private String shortCode;
    private Integer displayOrder;
}
