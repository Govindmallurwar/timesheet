package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.Employee;
import com.scrumconnect.timesheet.api.model.Project;
import com.scrumconnect.timesheet.api.model.Timesheet;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.TimesheetDto;
import com.scrumconnect.timesheet.api.model.dto.WeeklyTimesheetDto;
import com.scrumconnect.timesheet.api.service.EmployeeService;
import com.scrumconnect.timesheet.api.service.ProjectService;
import com.scrumconnect.timesheet.api.service.TimesheetService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@RequestMapping(path = "/timesheet")
public class TimesheetController {
    private final TimesheetService timesheetService;
    private final ProjectService projectService;
    private final EmployeeService employeeService;

    public TimesheetController(TimesheetService timesheetService,
                               ProjectService projectService,
                               EmployeeService employeeService) {
        this.timesheetService = timesheetService;
        this.projectService = projectService;
        this.employeeService = employeeService;
    }

    @GetMapping(
            produces = "application/json"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<List<WeeklyTimesheetDto>> findProjectTimesheets() {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(employee -> {
                    List<TimesheetDto> timesheetDtos =
                        timesheetService.findTimesheetsForEmployeeId(employee.getEmployee().getId())
                            .stream()
                            .map(Timesheet::toDto)
                            .toList();

                    Map<String, WeeklyTimesheetDto> groupedTimesheetDtos = new HashMap<>();
                    for (TimesheetDto dto : timesheetDtos) {
                        if (groupedTimesheetDtos.containsKey(dto.getEffectiveDateYearWeek())) {
                            List<TimesheetDto> updatedDtos = Stream
                                    .concat(groupedTimesheetDtos.get(dto.getEffectiveDateYearWeek()).getTimesheets().stream(), Stream.of(dto))
                                    .sorted(Comparator.comparing(TimesheetDto::getEffectiveDateDay))
                                    .collect(Collectors.toList());
                            groupedTimesheetDtos.get(dto.getEffectiveDateYearWeek()).setTimesheets(updatedDtos);
                        } else {
                            WeeklyTimesheetDto weeklyTimesheetDto = new WeeklyTimesheetDto();
                            weeklyTimesheetDto.setWeekStartDate(dto.getEffectiveDateFirstDayOfWeekSunday());
                            weeklyTimesheetDto.setEmployeeId(dto.getEmployeeId());
                            weeklyTimesheetDto.setTimesheets(List.of(dto));

                            weeklyTimesheetDto.setStatus("pending");

                            Optional<Project> project = projectService.findById(dto.getProjectId());
                            if (project.isPresent()) {
                                weeklyTimesheetDto.setProjectName(project.get().getName());
                            }

                            groupedTimesheetDtos.put(dto.getEffectiveDateYearWeek(), weeklyTimesheetDto);
                        }
                    }

                    return ResponseEntity.ok(groupedTimesheetDtos.values().stream().collect(Collectors.toList()));
                })
                .orElseGet(() -> ResponseEntity.status(401).build());
    }
}
