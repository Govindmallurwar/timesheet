package com.scrumconnect.timesheet.api.model.dto.request;

import lombok.Data;

import java.time.LocalDate;

@Data
public class NewProjectTimeUnitDto {
    private String projectId;
    private LocalDate effectiveDate;
    private String unit;
    private Integer baseUnit;   // How many minutes in this unit, e.g. 8 hours = 8 * 60 = 480
}
