package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.Company;
import com.scrumconnect.timesheet.api.model.dto.CompanyDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewCompanyDto;
import com.scrumconnect.timesheet.api.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class CompanyService {
    @Autowired
    private CompanyRepository companyRepository;

    public List<Company> findAll() {
        return companyRepository.findAll();
    }

    public Optional<Company> findOne(String id) {
        return companyRepository.findById(id);
    }

    public Company save(NewCompanyDto newCompanyDto) {
        Company companyToSave = new Company();
        companyToSave.setId(UUID.randomUUID().toString());
        companyToSave.setName(newCompanyDto.getName());

        return companyRepository.save(companyToSave);
    }

    public Boolean delete(String id) {
        Optional<Company> companyToDelete = companyRepository.findById(id);
        companyToDelete.ifPresent(
            company -> companyRepository.delete(company)
        );

        return companyToDelete.isPresent();
    }

    public Optional<Company> findByName(String companyName) {
        return companyRepository.findByName(companyName);
    }

    public Optional<Company> findById(String companyId) {
        return companyRepository.findById(companyId);
    }
}
