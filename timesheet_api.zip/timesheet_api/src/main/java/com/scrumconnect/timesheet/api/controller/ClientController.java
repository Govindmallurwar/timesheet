package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.Client;
import com.scrumconnect.timesheet.api.model.User;
import com.scrumconnect.timesheet.api.model.dto.ClientDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewClientDto;
import com.scrumconnect.timesheet.api.service.ClientService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.scrumconnect.timesheet.api.util.EmployeeUtil.getLoggedInEmployee;

@RestController
@CrossOrigin
@RequestMapping(path = "/client")
public class ClientController {
    @Autowired
    private ClientService clientService;

    @GetMapping(
            value = "/all",
            produces = "application/json"
    )
    public ResponseEntity<List<ClientDto>> findAll() {
        List<ClientDto> dtos = clientService.findAll().stream().map(Client::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/company/{companyId}")
    public ResponseEntity<List<ClientDto>> findAllByCompany(@PathVariable("companyId") String companyId) {
        List<ClientDto> dtos = clientService.findByCompanyId(companyId).stream().map(Client::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(
            value = "/{id}",
            produces = "application/json"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<ClientDto> findOne(@PathVariable("id") String id) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> clientService.findOne(id)
                            .map(client -> ResponseEntity.ok(client.toDto()))
                            .orElseGet(() -> ResponseEntity.notFound().build()))
                .orElseGet(() ->
                        ResponseEntity.status(401).build()
                );
    }

    @PostMapping(
            produces = "application/json"
    )
    @SecurityRequirement(name = "Bearer Authentication")
    public ResponseEntity<ClientDto> add(@RequestBody NewClientDto newClientDto) {
        Optional<User> loggedInEmployee = getLoggedInEmployee();

        return loggedInEmployee
                .map(user -> {
                    Client client = newClientDto.toObj(user.getEmployee().getCompanyId());

                    Client saved = clientService.save(client);
                    ClientDto savedDto = saved.toDto();
                    return ResponseEntity.ok(savedDto);
                })
                .orElseGet(() ->
                        ResponseEntity.status(401).build()
                );
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (clientService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
