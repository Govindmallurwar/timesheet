package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.ProjectTimeUnit;
import com.scrumconnect.timesheet.api.model.dto.ProjectTimeUnitDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectTimeUnitDto;
import com.scrumconnect.timesheet.api.service.ProjectTimeUnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping(path = "/project-time-unit")
public class ProjectTimeUnitController {
    @Autowired
    private ProjectTimeUnitService projectTimeUnitService;

    @GetMapping
    public ResponseEntity<List<ProjectTimeUnitDto>> findAll() {
        List<ProjectTimeUnitDto> dtos = projectTimeUnitService.findAll().stream().map(ProjectTimeUnit::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<ProjectTimeUnitDto> findOne(@PathVariable("id") String id) {
        return projectTimeUnitService.findOne(id)
            .map(company -> ResponseEntity.ok(company.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping(value = "/project/{projectId}")
    public ResponseEntity<List<ProjectTimeUnitDto>> findAllByProjectId(@PathVariable("projectId") String projectId) {
        List<ProjectTimeUnitDto> dtos = projectTimeUnitService.findByProjectId(projectId).stream().map(ProjectTimeUnit::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @PostMapping
    public ResponseEntity<ProjectTimeUnitDto> add(@RequestBody NewProjectTimeUnitDto newProjectTimeUnitDto) {
        return ResponseEntity.ok(projectTimeUnitService.save(newProjectTimeUnitDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (projectTimeUnitService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
