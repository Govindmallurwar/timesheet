package com.scrumconnect.timesheet.api.model;

import com.scrumconnect.timesheet.api.model.dto.ProjectEmployeeTimeBookedDto;
import com.scrumconnect.timesheet.api.model.dto.ProjectEmployeeTimeStatusDto;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
public class ProjectEmployeeTimeBooked {
    @Id
    private String id;
    private String projectEmployeeId;
    private String projectTimeUnitId;
    private LocalDateTime effectiveDate;
    private Integer units;

    @OneToMany
    private List<ProjectEmployeeTimeStatus> statuses;

    public ProjectEmployeeTimeBookedDto toDto() {
        ProjectEmployeeTimeBookedDto dto = new ProjectEmployeeTimeBookedDto();

        dto.setId(this.getId());
        dto.setProjectEmployeeId(this.getProjectEmployeeId());
        dto.setProjectTimeUnitId(this.getProjectTimeUnitId());
        dto.setEffectiveDate(this.getEffectiveDate());
        dto.setUnits(this.getUnits());

        List<ProjectEmployeeTimeStatusDto> statusesAsDto = new ArrayList<>();
        for (ProjectEmployeeTimeStatus status : statuses) {
            statusesAsDto.add(status.toDto());
        }
        dto.setStatuses(statusesAsDto);

        return dto;
    }
}
