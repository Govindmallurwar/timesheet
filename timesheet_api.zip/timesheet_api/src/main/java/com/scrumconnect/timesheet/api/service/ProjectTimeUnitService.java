package com.scrumconnect.timesheet.api.service;

import com.scrumconnect.timesheet.api.model.ProjectTimeUnit;
import com.scrumconnect.timesheet.api.model.dto.request.NewProjectTimeUnitDto;
import com.scrumconnect.timesheet.api.repository.ProjectTimeUnitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProjectTimeUnitService {
    @Autowired
    private ProjectTimeUnitRepository projectTimeUnitRepository;

    public List<ProjectTimeUnit> findAll() {
        return projectTimeUnitRepository.findAll();
    }

    public Optional<ProjectTimeUnit> findOne(String id) {
        return projectTimeUnitRepository.findById(id);
    }

    public ProjectTimeUnit save(NewProjectTimeUnitDto newProjectTimeUnitDto) {
        ProjectTimeUnit projectTimeUnitToSave = new ProjectTimeUnit();
        projectTimeUnitToSave.setId(UUID.randomUUID().toString());
        projectTimeUnitToSave.setProjectId(newProjectTimeUnitDto.getProjectId());
        projectTimeUnitToSave.setEffectiveDate(newProjectTimeUnitDto.getEffectiveDate());
        projectTimeUnitToSave.setUnit(newProjectTimeUnitDto.getUnit());
        projectTimeUnitToSave.setBaseUnit(newProjectTimeUnitDto.getBaseUnit());

        return projectTimeUnitRepository.save(projectTimeUnitToSave);
    }

    public Boolean delete(String id) {
        Optional<ProjectTimeUnit> projectTimeUnitToDelete = projectTimeUnitRepository.findById(id);
        projectTimeUnitToDelete.ifPresent(
            projectTimeUnit -> projectTimeUnitRepository.delete(projectTimeUnit)
        );

        return projectTimeUnitToDelete.isPresent();
    }

    public List<ProjectTimeUnit> findByProjectId(String projectId) {
        return projectTimeUnitRepository.findByProjectId(projectId);
    }
}
