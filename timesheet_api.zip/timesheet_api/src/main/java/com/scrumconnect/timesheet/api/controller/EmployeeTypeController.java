package com.scrumconnect.timesheet.api.controller;

import com.scrumconnect.timesheet.api.model.EmployeeType;
import com.scrumconnect.timesheet.api.model.dto.EmployeeTypeDto;
import com.scrumconnect.timesheet.api.model.dto.request.NewEmployeeTypeDto;
import com.scrumconnect.timesheet.api.service.EmployeeTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping(path = "/employee-type")
public class EmployeeTypeController {
    @Autowired
    private EmployeeTypeService employeeTypeService;

    @GetMapping
    public ResponseEntity<List<EmployeeTypeDto>> findAll() {
        List<EmployeeTypeDto> dtos = employeeTypeService.findAll().stream().map(EmployeeType::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/company/{companyId}")
    public ResponseEntity<List<EmployeeTypeDto>> findAllByCompany(@PathVariable("companyId") String companyId) {
        List<EmployeeTypeDto> dtos = employeeTypeService.findByCompanyId(companyId).stream().map(EmployeeType::toDto).collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<EmployeeTypeDto> findOne(@PathVariable("id") String id) {
        return employeeTypeService.findOne(id)
            .map(employeeType -> ResponseEntity.ok(employeeType.toDto()))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EmployeeTypeDto> add(@RequestBody NewEmployeeTypeDto newEmployeeTypeDto) {
        return ResponseEntity.ok(employeeTypeService.save(newEmployeeTypeDto).toDto());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") String id) {
        if (employeeTypeService.delete(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
