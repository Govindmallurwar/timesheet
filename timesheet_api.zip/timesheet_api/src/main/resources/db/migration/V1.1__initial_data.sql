insert into company (id, name) select UUID(), 'Scrumconnect';
