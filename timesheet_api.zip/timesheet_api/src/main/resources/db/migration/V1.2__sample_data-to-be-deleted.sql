
insert into employee_type (id, company_id, title, display_order)
select UUID(), c.id, 'Employee', 1
from company c where name='Scrumconnect';

insert into employee_type (id, company_id, title, display_order)
select UUID(), c.id, 'Contractor', 2
from company c where name='Scrumconnect';

insert into employee_details_key (id, company_id, detail_key, detail_type, display_order)
select UUID(), c.id, 'nino', 'nino', 1
from company c where name='Scrumconnect';

insert into employee_details_key (id, company_id, detail_key, detail_type, display_order)
select UUID(), c.id, 'contact_number', 'phone', 2
from company c where name='Scrumconnect';

insert into employee_details_key (id, company_id, detail_key, detail_type, display_order)
select UUID(), c.id, 'external_email', 'email', 3
from company c where name='Scrumconnect';

insert into employee_details_key (id, company_id, detail_key, detail_type, display_order)
select UUID(), c.id, 'dob', 'date', 4
from company c where name='Scrumconnect';

insert into employee_details_key (id, company_id, detail_key, detail_type, display_order)
select UUID(), c.id, 'nationality', 'text', 5
from company c where name='Scrumconnect';



