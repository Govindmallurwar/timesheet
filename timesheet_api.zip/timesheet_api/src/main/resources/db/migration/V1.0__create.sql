CREATE TABLE `company` (
    `id` char(36) NOT NULL,
    `name` varchar(200) NOT NULL,
    `created_at`  TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (`id`)
) ;

CREATE TABLE `client` (
    `id` char(36) NOT NULL,
    `company_id` char(36) NOT NULL,
    `name` varchar(200) NOT NULL,
    `short_code` varchar(5) NOT NULL,
    `created_at`  TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (`id`),
    CONSTRAINT client_short_code_unique UNIQUE KEY (short_code),
    CONSTRAINT client_company_FK FOREIGN KEY (company_id) REFERENCES company(id)
) ;

CREATE TABLE `employee_type` (
    `id` char(36) NOT NULL,
    `company_id` char(36) NOT NULL,
    `title` varchar(200) NOT NULL,
    `display_order` INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`),
    CONSTRAINT employee_type_company_FK FOREIGN KEY (company_id) REFERENCES company(id)
) ;

CREATE TABLE `employee_details_key` (
    `id` char(36) NOT NULL,
    `company_id` char(36) NOT NULL,
    `detail_key` varchar(200) NOT NULL,
    `detail_type` varchar(200) NOT NULL,
    `display_order` INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`),
    CONSTRAINT employee_details_key_company_FK FOREIGN KEY (company_id) REFERENCES company(id)
) ;

CREATE TABLE `employee` (
    `id` char(36) NOT NULL,
    `company_id` char(36) NOT NULL,
    `employee_type_id` char(36) NOT NULL,
    `email` varchar(200) NOT NULL,
    `first_name` varchar(200) NOT NULL,
    `last_name` varchar(200) NOT NULL,
    `start_date` TIMESTAMP NOT NULL DEFAULT NOW(),
    `end_date` TIMESTAMP NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT employee_detail_company_FK FOREIGN KEY (company_id) REFERENCES company(id),
    CONSTRAINT employee_detail_employee_type_FK FOREIGN KEY (employee_type_id) REFERENCES employee_type(id)
) ;

CREATE TABLE `project` (
    `id` char(36) NOT NULL,
    `client_id` char(36) NOT NULL,
    `name` varchar(200) NOT NULL,
    `po_number` varchar(200) NULL,
    `start_date` date NOT NULL,
    `end_date` date NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT project_client_FK FOREIGN KEY (client_id) REFERENCES client(id)
) ;

CREATE TABLE `employee_project_role` (
                                         `id` char(36) NOT NULL,
                                         `project_id` char(36) NOT NULL,
                                         `title` varchar(200) NOT NULL,
                                         `short_code` varchar(200) DEFAULT NULL,
                                         `display_order` INTEGER NOT NULL DEFAULT 1,
                                         PRIMARY KEY (`id`),
                                         CONSTRAINT employee_project_role_key_project_FK FOREIGN KEY (project_id) REFERENCES project(id)
) ;

CREATE TABLE `user` (
    `id` char(36) NOT NULL,
    `email` varchar(200) NOT NULL,
    `avatar` varchar(200) NULL,
    `password_hash` varchar(200) NOT NULL,
    `role` varchar(20) NULL DEFAULT 'Guest',
    `employee_id` char(36) NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT user_email_unique UNIQUE KEY (email),
    CONSTRAINT user_username_employee_unique UNIQUE KEY (employee_id),
    CONSTRAINT user_employee_FK FOREIGN KEY (employee_id) REFERENCES employee(id)
) ;

CREATE TABLE `employee_detail` (
    `id` char(36) NOT NULL,
    `employee_id` char(36) NOT NULL,
    `key_id` varchar(200) NOT NULL,
    `value` varchar(200) NOT NULL,
    `effective_date` TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (`id`),
    CONSTRAINT employee_detail_employee_FK FOREIGN KEY (employee_id) REFERENCES employee(id),
    CONSTRAINT employee_detail_employee_details_key_FK FOREIGN KEY (key_id) REFERENCES employee_details_key(id)
) ;

CREATE TABLE `project_time_unit` (
    `id` char(36) NOT NULL,
    `project_id` char(36) NOT NULL,
    `effective_date` TIMESTAMP NOT NULL DEFAULT NOW(),
    `unit` varchar(200) NOT NULL,
    `base_unit` INTEGER NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT project_time_unit_project_FK FOREIGN KEY (project_id) REFERENCES project(id)
) ;

CREATE TABLE `project_employee` (
    `id` char(36) NOT NULL,
    `project_id` char(36) NOT NULL,
    `employee_id` char(36) NOT NULL,
    `employee_project_role_id` char(36) NOT NULL,
    `start_date` TIMESTAMP NOT NULL DEFAULT NOW(),
    `end_date` TIMESTAMP NULL DEFAULT NULL,
    `is_approver` BIT DEFAULT 0,
    PRIMARY KEY (`id`),
    CONSTRAINT project_employee_project_FK FOREIGN KEY (project_id) REFERENCES project(id),
    CONSTRAINT project_employee_employee_FK FOREIGN KEY (employee_id) REFERENCES employee(id),
    CONSTRAINT project_employee_employee_project_role_FK FOREIGN KEY (employee_project_role_id) REFERENCES employee_project_role(id)
) ;

CREATE TABLE `employee_vacation_booked` (
    `id` char(36) NOT NULL,
    `employee_id` char(36) NOT NULL,
    `project_time_unit_id` char(36) NOT NULL,
    `effective_date` TIMESTAMP NOT NULL DEFAULT NOW(),
    `units` varchar(200) NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT employee_vacation_booked_employee_FK FOREIGN KEY (employee_id) REFERENCES employee(id),
    CONSTRAINT employee_vacation_booked_project_time_unit_key_FK FOREIGN KEY (project_time_unit_id) REFERENCES project_time_unit(id)
) ;

CREATE TABLE `project_employee_time_booked` (
    `id` char(36) NOT NULL,
    `project_employee_id` char(36) NOT NULL,
    `project_time_unit_id` char(36) NOT NULL,
    `effective_date` TIMESTAMP NOT NULL DEFAULT NOW(),
    `units` varchar(200) NOT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT project_employee_time_booked_project_employee_FK FOREIGN KEY (project_employee_id) REFERENCES project_employee(id),
    CONSTRAINT project_employee_time_booked_project_time_unit_key_FK FOREIGN KEY (project_time_unit_id) REFERENCES project_time_unit(id)
) ;

CREATE TABLE `project_employee_time_status` (
    `id` char(36) NOT NULL,
    `project_employee_id` char(36) NOT NULL,
    `project_employee_time_booked_id` char(36) NOT NULL,
    `project_time_unit_id` char(36) NOT NULL,
    `state` varchar(20) NOT NULL,
    `notes` VARCHAR(1024) NULL DEFAULT NULL,
    `notes_date` TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (`id`),
    CONSTRAINT project_employee_time_status_project_employee_time_booked_FK FOREIGN KEY (project_employee_time_booked_id) REFERENCES project_employee_time_booked(id),
    CONSTRAINT project_employee_time_status_project_employee_FK FOREIGN KEY (project_employee_id) REFERENCES project_employee(id),
    CONSTRAINT project_employee_time_status_project_time_unit_key_FK FOREIGN KEY (project_time_unit_id) REFERENCES project_time_unit(id)
) ;

create view daily_timesheet (
    id,
    company_id,
    company_name,
    client_id,
    client_name,
    project_id,
    project_name,
    employee_id,
    first_name,
    last_name,
    project_employee_time_booked_id,
    effective_date,
    booked_units,
    project_employee_id,
    project_time_unit_id,
    unit,
    base_unit,
    effective_date_year,
    effective_date_month,
    effective_date_day,
    effective_date_day_name,
    effective_date_year_week,
    effective_date_first_day_of_week_sunday,
    effective_date_first_day_of_week_monday
    ) as
select
    ROW_NUMBER() OVER () AS id,
    c.id,
    c.name,
    cl.id,
    cl.name,
    p.id,
    p.name,
    e.id,
    e.first_name,
    e.last_name,
    petb.id,
    petb.effective_date,
    petb.units,
    pe.id,
    ptu.id,
    ptu.unit,
    ptu.base_unit,
    YEAR(petb.effective_date),
    WEEK(petb.effective_date),
    WEEKDAY(petb.effective_date),
    DAYNAME(petb.effective_date),
    CONCAT(YEAR(petb.effective_date), '/', WEEK(petb.effective_date)),
    DATE_ADD(petb.effective_date, INTERVAL(1-WEEKDAY(petb.effective_date)) DAY),
    DATE_ADD(petb.effective_date, INTERVAL(-WEEKDAY(petb.effective_date)) DAY)
from company c, client cl, project p, project_employee_time_booked petb, project_employee pe, employee e, project_time_unit ptu
where cl.company_id = c.id
  and p.client_id = cl.id
  and petb.project_employee_id = pe.id
  and pe.employee_id = e.id
  and pe.project_id = p.id
  and petb.project_time_unit_id = ptu.id
order by petb.effective_date;
