# API
Scrumconnect Timesheet API

## Database
The database used is PostgreSQL

### Initial set up of database server
Before running the application for the first time the database server will need to be primed for use
by creating the empty database, and assigning user credentials.

## Database
The database used is MySQL 8

### Initial set up of database server
Before running the application for the first time the database server will need to be primed for use
by creating the empty database, and assigning user credentials.

#### database
##### Local connection
```shell
mysql -P 3306 -u timesheetuser -D timesheet -p
```

#### Database setup
```mysql
create database timesheet;
create user 'timesheetuser'@'localhost' identified by 'timesheet';
grant all privileges on timesheet.* to 'timesheetuser'@'localhost';
```

### Initialise a running system with an `Admin` user
Note: This will probably need improving by dynamically creating the user as well, currently this is done in the test data
```shell
curl -X 'POST' \
  'http://localhost:8080/authenticate/initialise' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "email": "markhunter@scrumconnect.com",
  "password": "admin"
}'
```

### Available endpoints
[Raw API Docs](http://localhost:8080/api-docs)

[Open API Docs](http://localhost:8080/swagger-ui/index.html)

# Things to resolve/sort out
- JWT/Spring Security not protecting endpoint properly (still available without Bearer Token!)

### Sample Data
#### SQL
```mysql
insert into employee (id, email, first_name, last_name, employee_type_id, company_id, start_date)
select UUID(), 'markhunter@scrumconnect.com', 'Mark', 'Hunter', et.id, et.company_id, '2023-07-01'
from employee_type et, company c
where et.title = 'Contractor'
  and et.company_id = c.id
  and c.name = 'Scrumconnect';

insert into employee (id, email, first_name, last_name, employee_type_id, company_id, start_date)
select UUID(), 'dhevendran@scrumconnect.com', 'Dhevendran', 'Natarajan', et.id, et.company_id, '2023-07-01'
from employee_type et, company c
where et.title = 'Employee'
  and et.company_id = c.id
  and c.name = 'Scrumconnect';

insert into client (id, company_id, name, short_code)
select UUID(), c.id, 'DWP Health', 'DWP-H'
from company c where name='Scrumconnect';

insert into project (id, client_id, name, start_date, approver_employee_id)
select UUID(), c.id, 'Workplace Health Assessment Subsidy', NOW(), e.id
from client c, company co, employee e
where co.name='Scrumconnect' and c.company_id=co.id and c.name='DWP Health'
and e.email = 'dhevendran@scrumconnect.com';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Admin', 0
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Delivery Manager', 1
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Business Analyst', 1
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Technical Architect', 2
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Admin', 2
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Lead Developer', 2
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Developer', 2
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'Lead QA Tester', 2
from project p where name='Workplace Health Assessment Subsidy';

insert into employee_project_role (id, project_id, title, display_order)
select UUID(), p.id, 'QA Tester', 2
from project p where name='Workplace Health Assessment Subsidy';

insert into project_employee (id, project_id, employee_id, employee_project_role_id, start_date)
select UUID(), p.id, e.id, epr.id, '2023-07-01'
from project p, employee e, employee_project_role epr
where p.name = 'Workplace Health Assessment Subsidy'
  and e.email = 'markhunter@scrumconnect.com'
  and epr.title = 'Technical Architect';

insert into project_employee (id, project_id, employee_id, employee_project_role_id, start_date)
select UUID(), p.id, e.id, epr.id, '2023-07-01'
from project p, employee e, employee_project_role epr
where p.name = 'Workplace Health Assessment Subsidy'
  and e.email = 'dhevendran@scrumconnect.com'
  and epr.title = 'Delivery Manager';

insert into project_time_unit (id, project_id, effective_date, unit, base_unit)
select UUID(), p.id, NOW(), 'Half Day - Morning', 240
from project p
where p.name = 'Workplace Health Assessment Subsidy';

insert into project_time_unit (id, project_id, effective_date, unit, base_unit)
select UUID(), p.id, NOW(), 'Half Day - Afternoon', 240
from project p
where p.name = 'Workplace Health Assessment Subsidy';

insert into project_time_unit (id, project_id, effective_date, unit, base_unit)
select UUID(), p.id, NOW(), 'Full Day', 480
from project p
where p.name = 'Workplace Health Assessment Subsidy';

insert into project_employee_time_booked (id, project_employee_id, project_time_unit_id, effective_date, units)
select UUID(), pe.id, ptu.id, '2024-04-29', 1
from project_employee pe, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and ptu.unit = 'Full Day';

insert into project_employee_time_booked (id, project_employee_id, project_time_unit_id, effective_date, units)
select UUID(), pe.id, ptu.id, '2024-04-30', 1
from project_employee pe, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and ptu.unit = 'Full Day';

insert into project_employee_time_booked (id, project_employee_id, project_time_unit_id, effective_date, units)
select UUID(), pe.id, ptu.id, '2024-05-01', 1
from project_employee pe, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and ptu.unit = 'Full Day';

insert into project_employee_time_booked (id, project_employee_id, project_time_unit_id, effective_date, units)
select UUID(), pe.id, ptu.id, '2024-05-02', 1
from project_employee pe, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and ptu.unit = 'Full Day';

insert into project_employee_time_booked (id, project_employee_id, project_time_unit_id, effective_date, units)
select UUID(), pe.id, ptu.id, '2024-05-03', 1
from project_employee pe, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and ptu.unit = 'Full Day';

insert into project_employee_time_booked (id, project_employee_id, project_time_unit_id, effective_date, units)
select UUID(), pe.id, ptu.id, '2024-05-06', 1
from project_employee pe, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and ptu.unit = 'Half Day - Morning';

insert into project_employee_time_booked (id, project_employee_id, project_time_unit_id, effective_date, units)
select UUID(), pe.id, ptu.id, '2024-05-07', 1
from project_employee pe, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and ptu.unit = 'Full Day';

insert into project_employee_time_status (id, project_employee_id, project_employee_time_booked_id, project_time_unit_id, state, notes, notes_date)
select UUID(), pe.id, petb.id, ptu.id, 'Approved', null, NOW()
from project_employee pe, project_employee_time_booked petb, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and petb.effective_date = '2024-05-07'
  and ptu.unit = 'Full Day';

insert into project_employee_time_status (id, project_employee_id, project_employee_time_booked_id, project_time_unit_id, state, notes, notes_date)
select UUID(), pe.id, petb.id, ptu.id, 'Rejected', null, NOW()
from project_employee pe, project_employee_time_booked petb, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and petb.effective_date = '2024-05-06'
  and ptu.unit = 'Half Day - Morning';

insert into project_employee_time_status (id, project_employee_id, project_employee_time_booked_id, project_time_unit_id, state, notes, notes_date)
select UUID(), pe.id, petb.id, ptu.id, 'Approved', null, NOW()
from project_employee pe, project_employee_time_booked petb, project_time_unit ptu
where pe.employee_id = (select id from employee e where e.email='markhunter@scrumconnect.com')
  and petb.effective_date = '2024-05-06'
  and ptu.unit = 'Full Day';
```